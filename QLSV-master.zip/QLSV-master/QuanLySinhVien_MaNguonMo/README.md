﻿*************************************************
*	TRƯỜNG ĐẠI HỌC THÔNG TIN LIÊN LẠC	*
*	     KHOA CÔNG NGHỆ THÔNG TIN		*
*						*
*	PHẦN MỀM QUẢN LÝ SINH VIÊN 		*
* 	Nhóm Tác Giả: Nhóm F4_DHCN1A		*
*		12/6/2017			*
*************************************************